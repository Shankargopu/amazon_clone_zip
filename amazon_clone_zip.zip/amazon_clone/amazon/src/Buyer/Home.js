import React from 'react'
import {auth1} from './firebaseBuyer'
import {useHistory} from 'react-router'
function Home(user) {
    const history=useHistory()
    return (
        <div>
            {
                 user ? <button onClick={()=>
                {
                    auth1.signOut()
                    history.push('/login')

                }}>Logout</button>
                 :
                 <button>Login</button>
            }
            
        </div>
    )
}

export default Home
