import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore/lite';
import { getAuth, createUserWithEmailAndPassword ,signInWithEmailAndPassword} from "firebase/auth";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage";
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyAaLI4buPHOXTWA2CbYDjTNmPXeoE3u34k",
    authDomain: "clone-df505.firebaseapp.com",
    projectId: "clone-df505",
    storageBucket: "clone-df505.appspot.com",
    messagingSenderId: "371181628191",
    appId: "1:371181628191:web:e9e1c6d0fa19ff37ef1e2a",
    measurementId: "G-D13B4FL177",
    databaseURL:"https://clone-df505-default-rtdb.firebaseio.com"
  };

 // export default !firebase.apps.length ? firebase.initializeApp(config) : firebase.app();
  
 const app = initializeApp(firebaseConfig);
 const db = getFirestore(app)
 const auth1= getAuth(app)
 const database = getDatabase(app);
const storage=getStorage(app)

  export {auth1,database,db,storage as default};
