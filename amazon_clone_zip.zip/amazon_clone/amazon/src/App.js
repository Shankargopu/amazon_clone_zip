import './App.css';
import Login from './Buyer/Login';
import {BrowserRouter as Router ,Switch ,Route} from 'react-router-dom'
import AddProduct from './Seller/AddProduct';
import Signup from './Buyer/Signup';
import Addproduct1 from './Seller/Addproduct1';
import SignupSeller from './Seller/SignupSeller';
import LoginSeller from './Seller/LoginSeller';
import Home from './Buyer/Home';
import React,{useState,useEffect} from 'react';
import {auth} from './Seller/firebaseSeller'
import { auth1 } from './Buyer/firebaseBuyer';
import HomeSeller from './Seller/HomeSeller';
import {  onAuthStateChanged } from "firebase/auth";
import{categories} from './Seller/categories'

function App() {
  
  const [user,setUser]=useState('')
  const [userb,setUser1]=useState('')
useEffect(()=>
{
  onAuthStateChanged(auth1, (user) => {
  if (user) {
    // User is signed in, see docs for a list of available properties
    // https://firebase.google.com/docs/reference/js/firebase.User
    setUser(user)
    // ...
  } else {
    // User is signed out
    // ...
    setUser(null)
  }
});
    
},[])

useEffect(()=>
{
  onAuthStateChanged(auth, (user) => {
  if (user) {
    // User is signed in, see docs for a list of available properties
    // https://firebase.google.com/docs/reference/js/firebase.User
    setUser1(userb)
    // ...
  } else {
    // User is signed out
    // ...
    setUser1(null)
  }
})
},[])

  return (
    
    <div className="App">
      <Router>
          <Switch>
          <Route path="/login">
          <Login/>
          </Route>
          <Route path="/Addproduct">
            <AddProduct />
          </Route>
          <Route path="/Signup">
            <Signup/>
          </Route>
          <Route path="/add">
          <Addproduct1 />
          </Route>
          <Route path="/SignupSeller">
          <SignupSeller/>
          </Route>
          <Route path="/LoginSeller">
          <LoginSeller/>
          </Route>
          <Route path="/Home">
          <Home user={user}/>
          </Route>
          <Route path="/HomeSeller">
          <HomeSeller user={userb} />
          </Route>
         
        </Switch>
      </Router>
      
    </div>
  );
}

export default App;

