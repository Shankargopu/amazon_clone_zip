import {React,Component} from 'react'

import {auth} from './firebaseSeller'
import { useHistory } from 'react-router'


export default function HomeSeller({userb}) {
    const history=useHistory()
    return (
        <div>
        {
            userb ? console.log("hey")
            
            
             : <button>Login</button> 
            
        }
        </div>
    )
}


