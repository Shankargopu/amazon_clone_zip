import './AddProduct.css';
import React, {useState,useEffect,useRef,Component} from 'react';
import  {auth,database} from './firebaseSeller'
import secondaryApp, { storage } from './firebaseSeller';



function AddProduct() {
   const [images,setImages]=useState([])
   const[urls,setUrls]=useState([])
   const[progress, setProgress]=useState(0)
   
   const handleChange =(e)=>
   {
      for(let i=0;i<e.target.files.length;i++)
      {
        const newImage=e.target.files[i]
       newImage ["id"]=Math.random();
         setImages((prevState)=>[...prevState,newImage])
      
   }
   }
   
   
   const handleUpload = (e) => {

      e.preventDefault()
      const promises=[]
      images.map((image)=>
      {
         const uploadTask = secondaryApp.storage().ref(`images/${image.name}`).put(image);
         promises.push(uploadTask)
         uploadTask.on(
           "state_changed",
           snapshot => {
            const progress = Math.round(
               (snapshot.bytesTransferred / snapshot.totalBytes) * 100
             );
             setProgress(progress);
             
           },
           error => {
             console.log(error);
           },
         async  () => {
   
            await secondaryApp.storage() .ref("images")
               .child(image.name)
               .getDownloadURL()
               .then(urls => {
                 setUrls((prevState)=>
                 
                    [...prevState,urls]
                 )
               });
           }
         );
       }); 
       Promise.all(promises).then(()=>alert("images uploaded")).catch((err)=>console.log(err))
      }
      
      
console.log("image: " ,images)
console.log("urls :",urls)
   
    window.onload=function()
    {
      
    }

  
    
  
    return (

 <div className="login">
                <div>
            <img className="login_logo"
            src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt=""/>
        </div>
        <div><progress value={progress} max="100"></progress></div>
            <h1>Become an
         <br/>Amazon seller</h1>
         <form>
        <div className="container">
         <h3><label >Product Name </label></h3>
        <input id="post" className="ProductName" type='text'/>
        <br/>
       <h3>  <label >Product Image </label> </h3>
        <input type="file" multiple id="image"className="image-upload" onChange={handleChange} accept=".jpg,.png,jpeg"  />
        <br/>
     <h3>  <label> Description </label></h3>
        <input  className="Description"type="text"/>
        <br></br>
      <h3><label>  Price </label></h3>
                  <input className="Price" type="text"/>
                  <button className="upload_button" onClick={handleUpload} >Upload</button>
                  <br/>
                  {urls.map((url,i)=>(
                     <div ley={i}>
                        {url}
                     </div>
                  ))}
                  <br/>
                  {urls.map((url,i)=>(
                      <img key={i} className="image-display" src={urls || "http://via.placeholder.com/10"} alt="image"></img>
                     
                  ))}
                  <p></p>
                  
                 

  
        </div>
        </form>
        </div> 
               
   

    )
}


   


export default AddProduct